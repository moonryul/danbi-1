﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VGB_Clapping : MonoBehaviour
{
    public bool bClapping;

    void Start()
    {
        bClapping = false;
    }

    private void FixedUpdate()
    {
        // if (bClapping)
        // {
        //     Debug.Log("Clapping");
        // }
    }

}
